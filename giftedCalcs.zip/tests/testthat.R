library(testthat)
library(giftedCalcs)

test_check("giftedCalcs")
